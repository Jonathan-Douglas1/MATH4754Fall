.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to Intro2R")

}
