## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "ws#>",
  fig.align = "center"
)

# directory to Lab
dirdl <- system.file("shiny",package = "Intro2R")

# create rmd link

library(Intro2R)

## ----eval=FALSE---------------------------------------------------------------
#  
#  fileInput(
#    inputId,
#    label,
#    multiple = FALSE,
#    accept = NULL,
#    width = NULL,
#    buttonLabel = "Browse...",
#    placeholder = "No file selected"
#  )
#  
#  

## ----eval=FALSE---------------------------------------------------------------
#  checkboxGroupInput(
#    inputId,
#    label,
#    choices = NULL,
#    selected = NULL,
#    inline = FALSE,
#    width = NULL,
#    choiceNames = NULL,
#    choiceValues = NULL
#  )
#  
#  

## ----eval=FALSE---------------------------------------------------------------
#   ui <- fluidPage(
#        sidebarLayout(
#          sidebarPanel(
#            fileInput("fileName", "Choose a CSV File", accept = ".csv"),
#            checkboxInput("header", "Has a header!", TRUE)
#          ),
#          mainPanel(
#            tableOutput("fileContents")
#          )
#        )
#      )

## ----eval = FALSE-------------------------------------------------------------
#  server <- function(input, output) {
#        output$fileContents <- renderTable({
#          newfile <- input$fileName
#          ext <- tools::file_ext(newfile$datapath)
#  
#          req(newfile)
#          validate(need(ext == "csv", "Please upload a csv file"))
#  
#          read.csv(newfile$datapath, header = input$header)
#        })
#      }

## ----eval = FALSE-------------------------------------------------------------
#  ## Only run examples in interactive R sessions
#  interactive()
#  if (interactive()) {
#  
#  ui <- fluidPage(
#    sidebarLayout(
#      sidebarPanel(
#        fileInput("fileName", "Choose a CSV File", accept = ".csv"),
#        checkboxInput("header", "Has a header", TRUE)
#      ),
#      mainPanel(
#        tableOutput("fileContents")
#      )
#    )
#  )
#  
#  server <- function(input, output) {
#    output$fileContents <- renderTable({
#      newfile <- input$fileName
#      ext <- tools::file_ext(newfile$datapath)
#  
#      req(newfile)
#      validate(need(ext == "csv", "Please upload a csv file"))
#  
#  
#      read.csv(newfile$datapath, header = input$header)
#    })
#  }
#  
#  shinyApp(ui, server)
#  }
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  library(ggplot2)
#  
#  ui <- fluidPage(
#  
#    titlePanel("Plotting data"),
#  
#    sidebarLayout(
#  
#      sidebarPanel(
#  
#        fileInput("file", "Select csv file:", accept = ".csv"),
#        checkboxInput("header", "The file has a header!", TRUE),
#        br(),
#  
#        varSelectInput("var1", "Variable 1:", data()),
#        varSelectInput("var2", "Variable 2:", data()),
#  
#        checkboxInput("scatter", "Scatter plot", TRUE)
#  
#  
#           ),
#  
#      mainPanel(
#  
#        plotOutput("plot1")
#  
#  
#  
#  
#      )
#    )
#  )
#  
#  server <- function(input, output, session) {
#    # read input file and update choices for variable selection widget
#    data <- reactive({
#      req(input$file)
#     read.csv(input$file$datapath, header = input$header)
#  
#    })
#  
#  
#  
#    # create first plot given data and selected variables
#    output$plot1 <- renderPlot({
#      req(input$file, input$var1, input$var2)
#  
#      # store selected variables in df
#      df <- data()[,c(input$var1, input$var2)]
#  
#      # create ggplot
#      g <- ggplot(df, aes(x = df[,1], y = df[,2])) +
#        labs(title = paste("Plot of", input$var1, "vs.", input$var2), x = input$var1, y = input$var2)
#  
#      # add regression line and/or marginal plots given user input
#      if (input$scatter) {
#        g <- g + geom_smooth(method = "lm")
#  
#      }
#      else {
#        g <- g + geom_boxplot()
#      }
#      print(g)
#    })
#  
#  
#  }
#  
#  # Run the application
#  shinyApp(ui = ui, server = server)
#  

