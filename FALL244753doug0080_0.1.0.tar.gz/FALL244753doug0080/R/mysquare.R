#' Squareeeee
#'
#' @param x a vector of quantitative data
#'
#' @return square
#' @export
#'
#' @examples
#' mysquare(x = 1:10)
mysquare <- function(x){
  x**2
}
#RAHHHHHHH
